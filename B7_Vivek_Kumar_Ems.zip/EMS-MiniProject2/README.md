# Employee Management System — Mini Project 2

**Full-stack HR portal:** .NET 8 Web API + SQL Server 2022 + jQuery/Bootstrap 5 frontend.

---

## Prerequisites

| Tool | Version | Notes |
|------|---------|-------|
| .NET SDK | 8.0+ | https://dotnet.microsoft.com/download |
| SQL Server | 2022 | Express edition is free |
| dotnet-ef CLI | Latest | `dotnet tool install --global dotnet-ef` |
| VS Code + Live Server | Any | For serving the frontend |
| Node.js | 18+ | Only needed to run Mini Project 1 Jest tests |

---

## Step-by-Step Setup

### 1. Configure the connection string

Open `EMS.API/appsettings.json` and verify:

```json
"DefaultConnection": "Server=localhost;Database=EMSDashboard;Trusted_Connection=True;TrustServerCertificate=True;"
```

For a named SQL Server instance (e.g. SQLEXPRESS):
```
Server=localhost\SQLEXPRESS;Database=EMSDashboard;Trusted_Connection=True;TrustServerCertificate=True;
```

### 2. Restore NuGet packages

```bash
cd EMS.API
dotnet restore
```

### 3. Run EF Core migrations (REQUIRED before first run)

**In Visual Studio Package Manager Console:**
```
PM> Add-Migration InitialCreate
PM> Update-Database
```

**Or via CLI:**
```bash
cd EMS.API
dotnet ef migrations add InitialCreate
dotnet ef database update
```

This creates the `EMSDashboard` database, all tables, and seeds:
- 15 employees across 5 departments
- 2 default users: `admin/admin123` (Admin) and `viewer/viewer123` (Viewer)

### 4. Run the API

```bash
cd EMS.API
dotnet run
```

API runs at: **http://localhost:5000**  
Swagger UI: **http://localhost:5000/swagger**

### 5. Open the Frontend

In VS Code, right-click `frontend/index.html` → **Open with Live Server** (port 5500).

Or open `frontend/index.html` directly in Chrome — both origins are whitelisted in CORS.

### 6. Log in

| Username | Password | Role |
|----------|----------|------|
| admin    | admin123 | Admin (full CRUD) |
| viewer   | viewer123 | Viewer (read-only) |

---

## Run Backend Tests

```bash
cd EMS.Tests
dotnet test
```

Or in Visual Studio: **Test Explorer → Run All**

---

## Project Structure

```
EMS-MiniProject2/
├── EMS.API/                        ← .NET 8 Web API
│   ├── Controllers/
│   │   ├── EmployeesController.cs  ← CRUD + /dashboard + pagination
│   │   └── AuthController.cs       ← /auth/register + /auth/login
│   ├── Data/
│   │   └── AppDbContext.cs         ← EF Core DbContext + seed data
│   ├── DTOs/
│   │   └── EmployeeDtos.cs         ← all request/response DTOs
│   ├── Models/
│   │   ├── Employee.cs
│   │   └── AppUser.cs
│   ├── Services/
│   │   ├── IEmployeeRepository.cs  ← data access contract (for Moq)
│   │   ├── EmployeeRepository.cs   ← EF Core implementation
│   │   ├── EmployeeService.cs      ← business logic + SQL filtering
│   │   └── AuthService.cs          ← BCrypt + JWT
│   ├── appsettings.json
│   └── Program.cs                  ← DI, CORS, Swagger, JWT
│
├── EMS.Tests/                      ← NUnit + Moq test project
│   ├── Services/
│   │   ├── EmployeeServiceTests.cs
│   │   └── AuthServiceTests.cs
│   └── Controllers/
│       └── EmployeesControllerTests.cs
│
└── frontend/                       ← Updated frontend from Mini Project 1
    ├── index.html
    ├── css/styles.css
    └── js/
        ├── config.js               ← NEW: API_BASE_URL constant
        ├── storageService.js       ← REPLACED: real fetch() API calls
        ├── authService.js          ← UPDATED: calls /api/auth/*
        ├── employeeService.js      ← UPDATED: async delegates
        ├── validationService.js    ← UPDATED: added mapServerErrors()
        ├── dashboardService.js     ← UPDATED: single API call
        ├── uiService.js            ← UPDATED: pagination + role UI
        └── app.js                  ← UPDATED: async/await + pagination state
```

---

## API Endpoints

| Method | Endpoint | Role | Description |
|--------|----------|------|-------------|
| POST | /api/auth/register | Public | Register new user |
| POST | /api/auth/login | Public | Login, returns JWT |
| GET | /api/employees | Admin+Viewer | Paged list with search/filter/sort |
| GET | /api/employees/{id} | Admin+Viewer | Single employee |
| GET | /api/employees/dashboard | Admin+Viewer | KPIs + breakdown + recent |
| POST | /api/employees | Admin | Create employee |
| PUT | /api/employees/{id} | Admin | Update employee |
| DELETE | /api/employees/{id} | Admin | Delete employee |

### Query Parameters (GET /api/employees)

| Param | Default | Description |
|-------|---------|-------------|
| search | — | Name or email (case-insensitive LIKE) |
| department | — | Exact match filter |
| status | — | Active \| Inactive |
| sortBy | name | name \| salary \| joinDate |
| sortDir | asc | asc \| desc |
| page | 1 | 1-based page number |
| pageSize | 10 | Max 100 |

---

## Architecture Notes

- All filtering and sorting executes as **SQL** — not in JavaScript
- Only the current page's records are transferred (Skip/Take)
- JWT stored **in-memory only** — never in localStorage (XSS protection)
- `employeeService.js`, `dashboardService.js`, `validationService.js`, `uiService.js`, `app.js` required **zero architectural changes** from Mini Project 1 — only `storageService.js` and `authService.js` changed

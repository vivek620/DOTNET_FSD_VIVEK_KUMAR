using EMS.API.Data;
using EMS.API.DTOs;
using EMS.API.Models;
using EMS.API.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;

namespace EMS.Tests.Services
{
    /// <summary>
    /// Unit tests for AuthService.
    /// Uses EF Core InMemory database and Moq for IConfiguration.
    /// </summary>
    [TestFixture]
    public class AuthServiceTests
    {
        private AppDbContext   _db     = null!;
        private AuthService    _service = null!;
        private IConfiguration _config  = null!;

        [SetUp]
        public void Setup()
        {
            // Fresh in-memory DB per test
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _db = new AppDbContext(options);

            // Mock IConfiguration for JWT settings
            var mockConfig = new Mock<IConfiguration>();
            mockConfig.Setup(c => c["Jwt:Key"])         .Returns("TestSecretKey_32Chars_ForNUnit!!");
            mockConfig.Setup(c => c["Jwt:Issuer"])      .Returns("EMS.API");
            mockConfig.Setup(c => c["Jwt:Audience"])    .Returns("EMS.Client");
            mockConfig.Setup(c => c["Jwt:ExpiryHours"]) .Returns("8");

            _config  = mockConfig.Object;
            _service = new AuthService(_db, _config);
        }

        [TearDown]
        public void TearDown()
        {
            _db.Dispose();
        }

        // ─── Register ──────────────────────────────────────────────────────────

        [Test]
        public async Task RegisterAsync_NewUser_ReturnsSuccess()
        {
            var dto = new AuthRequestDto { Username = "newuser", Password = "pass123", Role = "Admin" };

            var result = await _service.RegisterAsync(dto);

            Assert.That(result.Success, Is.True);
            Assert.That(result.Username, Is.EqualTo("newuser"));
            Assert.That(result.Role,     Is.EqualTo("Admin"));
        }

        [Test]
        public async Task RegisterAsync_DuplicateUsername_ReturnsFailure()
        {
            // Seed existing user
            _db.Users.Add(new AppUser
            {
                Username     = "existing",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("pass123"),
                Role         = "Viewer"
            });
            await _db.SaveChangesAsync();

            var dto = new AuthRequestDto { Username = "existing", Password = "pass456", Role = "Viewer" };

            var result = await _service.RegisterAsync(dto);

            Assert.That(result.Success, Is.False);
            Assert.That(result.Message, Does.Contain("already taken"));
        }

        [Test]
        public async Task RegisterAsync_ShortPassword_ReturnsFailure()
        {
            var dto = new AuthRequestDto { Username = "userX", Password = "12", Role = "Viewer" };

            var result = await _service.RegisterAsync(dto);

            Assert.That(result.Success, Is.False);
            Assert.That(result.Message, Does.Contain("6 characters"));
        }

        // ─── Login ─────────────────────────────────────────────────────────────

        [Test]
        public async Task LoginAsync_ValidCredentials_ReturnsToken()
        {
            // Seed a user
            _db.Users.Add(new AppUser
            {
                Username     = "admin",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin123"),
                Role         = "Admin"
            });
            await _db.SaveChangesAsync();

            var dto = new AuthRequestDto { Username = "admin", Password = "admin123" };

            var result = await _service.LoginAsync(dto);

            Assert.That(result.Success, Is.True);
            Assert.That(result.Token,   Is.Not.Null.And.Not.Empty);
            Assert.That(result.Role,    Is.EqualTo("Admin"));
        }

        [Test]
        public async Task LoginAsync_WrongPassword_ReturnsFailure()
        {
            _db.Users.Add(new AppUser
            {
                Username     = "admin",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin123"),
                Role         = "Admin"
            });
            await _db.SaveChangesAsync();

            var dto = new AuthRequestDto { Username = "admin", Password = "wrongpass" };

            var result = await _service.LoginAsync(dto);

            Assert.That(result.Success, Is.False);
            Assert.That(result.Token,   Is.Null);
        }

        [Test]
        public async Task LoginAsync_NonExistentUser_ReturnsFailure()
        {
            var dto = new AuthRequestDto { Username = "ghost", Password = "any" };

            var result = await _service.LoginAsync(dto);

            Assert.That(result.Success, Is.False);
        }

        // ─── GenerateToken ─────────────────────────────────────────────────────

        [Test]
        public void GenerateToken_ValidUser_ReturnsNonEmptyString()
        {
            var user = new AppUser
            {
                Id       = 1,
                Username = "tokenUser",
                Role     = "Admin"
            };

            var token = _service.GenerateToken(user);

            Assert.That(token, Is.Not.Null.And.Not.Empty);
            // JWT tokens have 3 parts separated by dots
            Assert.That(token.Split('.').Length, Is.EqualTo(3));
        }
    }
}

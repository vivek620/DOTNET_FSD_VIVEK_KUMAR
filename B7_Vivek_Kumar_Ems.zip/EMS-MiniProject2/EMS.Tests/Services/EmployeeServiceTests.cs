using EMS.API.DTOs;
using EMS.API.Models;
using EMS.API.Services;
using Moq;
using NUnit.Framework;

namespace EMS.Tests.Services
{
    /// <summary>
    /// Unit tests for EmployeeService using Moq.
    /// Tests run against business logic with no real database involved.
    /// </summary>
    [TestFixture]
    public class EmployeeServiceTests
    {
        private Mock<IEmployeeRepository> _repoMock = null!;
        private EmployeeService _service = null!;

        [SetUp]
        public void Setup()
        {
            _repoMock = new Mock<IEmployeeRepository>();
            _service  = new EmployeeService(_repoMock.Object);
        }

        // ─── GetByIdAsync ──────────────────────────────────────────────────────

        [Test]
        public async Task GetByIdAsync_ValidId_ReturnsMappedDto()
        {
            // Arrange
            var fakeEmployee = new Employee
            {
                Id = 1, FirstName = "Priya", LastName = "Menon",
                Email = "priya@xyz.com", Phone = "9876543210",
                Department = "Engineering", Designation = "SE",
                Salary = 750000, JoinDate = DateTime.UtcNow,
                Status = "Active", CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow
            };

            _repoMock.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(fakeEmployee);

            // Act
            var result = await _service.GetByIdAsync(1);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result!.FirstName, Is.EqualTo("Priya"));
            Assert.That(result.LastName,   Is.EqualTo("Menon"));
            _repoMock.Verify(r => r.GetByIdAsync(1), Times.Once);
        }

        [Test]
        public async Task GetByIdAsync_NonExistentId_ReturnsNull()
        {
            // Arrange
            _repoMock.Setup(r => r.GetByIdAsync(9999)).ReturnsAsync((Employee?)null);

            // Act
            var result = await _service.GetByIdAsync(9999);

            // Assert
            Assert.That(result, Is.Null);
        }

        // ─── CreateAsync ───────────────────────────────────────────────────────

        [Test]
        public async Task CreateAsync_NewEmail_CallsAddAndSave()
        {
            // Arrange
            var dto = new EmployeeRequestDto
            {
                FirstName = "Rahul", LastName = "Sharma",
                Email = "rahul@xyz.com", Phone = "9123456780",
                Department = "Engineering", Designation = "Dev",
                Salary = 900000, JoinDate = DateTime.UtcNow,
                Status = "Active"
            };

            _repoMock.Setup(r => r.EmailExistsAsync(dto.Email, null)).ReturnsAsync(false);
            _repoMock.Setup(r => r.AddAsync(It.IsAny<Employee>())).Returns(Task.CompletedTask);
            _repoMock.Setup(r => r.SaveChangesAsync()).Returns(Task.CompletedTask);

            // Act
            var result = await _service.CreateAsync(dto);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result!.Email, Is.EqualTo("rahul@xyz.com"));
            _repoMock.Verify(r => r.AddAsync(It.IsAny<Employee>()), Times.Once);
            _repoMock.Verify(r => r.SaveChangesAsync(), Times.Once);
        }

        [Test]
        public async Task CreateAsync_DuplicateEmail_ReturnsNull()
        {
            // Arrange
            var dto = new EmployeeRequestDto
            {
                FirstName = "Test", LastName = "User",
                Email = "exists@xyz.com", Phone = "9000000001",
                Department = "HR", Designation = "Exec",
                Salary = 500000, JoinDate = DateTime.UtcNow,
                Status = "Active"
            };

            _repoMock.Setup(r => r.EmailExistsAsync(dto.Email, null)).ReturnsAsync(true);

            // Act
            var result = await _service.CreateAsync(dto);

            // Assert
            Assert.That(result, Is.Null);
            _repoMock.Verify(r => r.AddAsync(It.IsAny<Employee>()), Times.Never);
        }

        // ─── DeleteAsync ───────────────────────────────────────────────────────

        [Test]
        public async Task DeleteAsync_ExistingId_ReturnsTrueAndCallsRemove()
        {
            // Arrange
            var emp = new Employee
            {
                Id = 5, FirstName = "Delete", LastName = "Me",
                Email = "del@xyz.com", Phone = "9000000005",
                Department = "Operations", Designation = "Coord",
                Salary = 400000, JoinDate = DateTime.UtcNow,
                Status = "Active"
            };

            _repoMock.Setup(r => r.GetByIdAsync(5)).ReturnsAsync(emp);
            _repoMock.Setup(r => r.RemoveAsync(emp)).Returns(Task.CompletedTask);
            _repoMock.Setup(r => r.SaveChangesAsync()).Returns(Task.CompletedTask);

            // Act
            var result = await _service.DeleteAsync(5);

            // Assert
            Assert.That(result, Is.True);
            _repoMock.Verify(r => r.RemoveAsync(emp), Times.Once);
            _repoMock.Verify(r => r.SaveChangesAsync(), Times.Once);
        }

        [Test]
        public async Task DeleteAsync_NonExistentId_ReturnsFalse()
        {
            // Arrange
            _repoMock.Setup(r => r.GetByIdAsync(999)).ReturnsAsync((Employee?)null);

            // Act
            var result = await _service.DeleteAsync(999);

            // Assert
            Assert.That(result, Is.False);
            _repoMock.Verify(r => r.RemoveAsync(It.IsAny<Employee>()), Times.Never);
        }

        // ─── UpdateAsync ───────────────────────────────────────────────────────

        [Test]
        public async Task UpdateAsync_ValidUpdate_ReturnsUpdatedDto()
        {
            // Arrange
            var existing = new Employee
            {
                Id = 2, FirstName = "Old", LastName = "Name",
                Email = "old@xyz.com", Phone = "9000000002",
                Department = "Finance", Designation = "Analyst",
                Salary = 600000, JoinDate = DateTime.UtcNow,
                Status = "Active", CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow
            };

            var dto = new EmployeeRequestDto
            {
                FirstName = "New", LastName = "Name",
                Email = "old@xyz.com", Phone = "9000000002",
                Department = "Finance", Designation = "Senior Analyst",
                Salary = 700000, JoinDate = DateTime.UtcNow,
                Status = "Active"
            };

            _repoMock.Setup(r => r.GetByIdAsync(2)).ReturnsAsync(existing);
            _repoMock.Setup(r => r.EmailExistsAsync(dto.Email, 2)).ReturnsAsync(false);
            _repoMock.Setup(r => r.UpdateAsync(existing)).Returns(Task.CompletedTask);
            _repoMock.Setup(r => r.SaveChangesAsync()).Returns(Task.CompletedTask);

            // Act
            var (found, emailConflict, result) = await _service.UpdateAsync(2, dto);

            // Assert
            Assert.That(found, Is.True);
            Assert.That(emailConflict, Is.False);
            Assert.That(result, Is.Not.Null);
            Assert.That(result!.FirstName, Is.EqualTo("New"));
            Assert.That(result.Salary,     Is.EqualTo(700000));
        }
    }
}

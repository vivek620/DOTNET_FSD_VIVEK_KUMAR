using EMS.API.Controllers;
using EMS.API.DTOs;
using EMS.API.Models;
using EMS.API.Services;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;

namespace EMS.Tests.Controllers
{
    /// <summary>
    /// Unit tests for EmployeesController.
    /// Uses Moq to mock EmployeeService dependencies — no real DB or HTTP pipeline.
    /// </summary>
    [TestFixture]
    public class EmployeesControllerTests
    {
        private Mock<IEmployeeRepository> _repoMock   = null!;
        private EmployeeService           _service     = null!;
        private EmployeesController       _controller  = null!;

        [SetUp]
        public void Setup()
        {
            _repoMock   = new Mock<IEmployeeRepository>();
            _service    = new EmployeeService(_repoMock.Object);
            _controller = new EmployeesController(_service);
        }

        // ─── GetById ───────────────────────────────────────────────────────────

        [Test]
        public async Task GetById_ExistingEmployee_Returns200WithDto()
        {
            var emp = new Employee
            {
                Id = 1, FirstName = "Priya", LastName = "Menon",
                Email = "priya@xyz.com", Phone = "9876543210",
                Department = "Engineering", Designation = "SE",
                Salary = 750000, JoinDate = DateTime.UtcNow,
                Status = "Active", CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow
            };

            _repoMock.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(emp);

            var result = await _controller.GetById(1);

            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var ok = (OkObjectResult)result;
            Assert.That(ok.Value, Is.InstanceOf<EmployeeResponseDto>());
            var dto = (EmployeeResponseDto)ok.Value!;
            Assert.That(dto.Id, Is.EqualTo(1));
        }

        [Test]
        public async Task GetById_NonExistentId_Returns404()
        {
            _repoMock.Setup(r => r.GetByIdAsync(999)).ReturnsAsync((Employee?)null);

            var result = await _controller.GetById(999);

            Assert.That(result, Is.InstanceOf<NotFoundObjectResult>());
        }

        // ─── Delete ────────────────────────────────────────────────────────────

        [Test]
        public async Task Delete_ExistingId_Returns200()
        {
            var emp = new Employee
            {
                Id = 3, FirstName = "Del", LastName = "Emp",
                Email = "del@xyz.com", Phone = "9000000003",
                Department = "Operations", Designation = "Coord",
                Salary = 400000, JoinDate = DateTime.UtcNow,
                Status = "Active"
            };

            _repoMock.Setup(r => r.GetByIdAsync(3)).ReturnsAsync(emp);
            _repoMock.Setup(r => r.RemoveAsync(emp)).Returns(Task.CompletedTask);
            _repoMock.Setup(r => r.SaveChangesAsync()).Returns(Task.CompletedTask);

            var result = await _controller.Delete(3);

            Assert.That(result, Is.InstanceOf<OkObjectResult>());
        }

        [Test]
        public async Task Delete_NonExistentId_Returns404()
        {
            _repoMock.Setup(r => r.GetByIdAsync(888)).ReturnsAsync((Employee?)null);

            var result = await _controller.Delete(888);

            Assert.That(result, Is.InstanceOf<NotFoundObjectResult>());
        }

        // ─── Create ────────────────────────────────────────────────────────────

        [Test]
        public async Task Create_DuplicateEmail_Returns409Conflict()
        {
            var dto = new EmployeeRequestDto
            {
                FirstName = "Test", LastName = "User",
                Email = "dup@xyz.com", Phone = "9000000099",
                Department = "HR", Designation = "Exec",
                Salary = 500000, JoinDate = DateTime.UtcNow,
                Status = "Active"
            };

            _repoMock.Setup(r => r.EmailExistsAsync(dto.Email, null)).ReturnsAsync(true);

            var result = await _controller.Create(dto);

            Assert.That(result, Is.InstanceOf<ConflictObjectResult>());
        }

        [Test]
        public async Task Create_ValidEmployee_Returns201Created()
        {
            var dto = new EmployeeRequestDto
            {
                FirstName = "New", LastName = "Employee",
                Email = "new@xyz.com", Phone = "9111222333",
                Department = "Marketing", Designation = "Executive",
                Salary = 600000, JoinDate = DateTime.UtcNow,
                Status = "Active"
            };

            _repoMock.Setup(r => r.EmailExistsAsync(dto.Email, null)).ReturnsAsync(false);
            _repoMock.Setup(r => r.AddAsync(It.IsAny<Employee>())).Returns(Task.CompletedTask);
            _repoMock.Setup(r => r.SaveChangesAsync()).Returns(Task.CompletedTask);

            var result = await _controller.Create(dto);

            Assert.That(result, Is.InstanceOf<CreatedAtActionResult>());
        }
    }
}

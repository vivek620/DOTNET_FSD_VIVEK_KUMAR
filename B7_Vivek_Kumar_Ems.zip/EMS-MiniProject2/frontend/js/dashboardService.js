/**
 * dashboardService.js
 * UPDATED in Mini Project 2.
 * getSummary() now calls /api/employees/dashboard — one API call returns
 * KPIs, department breakdown, and recent employees together.
 * Business logic only — never touches the DOM.
 */

const DashboardService = (() => {

    /**
     * Fetches all dashboard data in a single API call.
     * Returns: { totalEmployees, activeEmployees, inactiveEmployees,
     *            totalDepartments, departmentBreakdown, recentEmployees }
     * @returns {Promise<DashboardSummary>}
     */
    async function getSummary() {
        return StorageService.getDashboard();
    }

    /**
     * Convenience accessor — returns just the KPI counts.
     * @returns {Promise<{ total, active, inactive, departments }>}
     */
    async function getKpis() {
        const data = await getSummary();
        return {
            total:       data.totalEmployees,
            active:      data.activeEmployees,
            inactive:    data.inactiveEmployees,
            departments: data.totalDepartments
        };
    }

    /**
     * Convenience accessor — returns per-department breakdown.
     * @returns {Promise<DepartmentBreakdown[]>}
     */
    async function getDepartmentBreakdown() {
        const data = await getSummary();
        return data.departmentBreakdown;
    }

    /**
     * Convenience accessor — returns recent employees list.
     * @param {number} n - Number of recent employees (default 5)
     * @returns {Promise<Employee[]>}
     */
    async function getRecentEmployees(n = 5) {
        const data = await getSummary();
        return data.recentEmployees.slice(0, n);
    }

    return { getSummary, getKpis, getDepartmentBreakdown, getRecentEmployees };

})();

/**
 * uiService.js
 * UPDATED in Mini Project 2.
 * renderEmployeeTable() now accepts a paged result object and renders
 * a Bootstrap pagination bar.
 * applyRoleUI() shows/hides write buttons based on Admin/Viewer role.
 * DOM operations only — no business logic.
 */

const UIService = (() => {

    // ── Employee Table ─────────────────────────────────────────────────────────

    /**
     * Renders the employee table from a paged result.
     * @param {PagedResult} pagedResult - { data, totalCount, page, pageSize, totalPages }
     */
    function renderEmployeeTable(pagedResult) {
        const tbody   = $("#employeeTableBody");
        const employees = pagedResult.data || [];

        tbody.empty();

        if (employees.length === 0) {
            tbody.append(`
                <tr>
                    <td colspan="10" class="text-center text-muted py-4">
                        <i class="bi bi-search fs-3 d-block mb-2"></i>
                        No employees found.
                    </td>
                </tr>
            `);
        } else {
            employees.forEach((emp, index) => {
                const statusBadge = emp.status === "Active"
                    ? `<span class="badge bg-success">Active</span>`
                    : `<span class="badge bg-secondary">Inactive</span>`;

                const deptClass = {
                    "Engineering": "dept-engineering",
                    "Marketing":   "dept-marketing",
                    "HR":          "dept-hr",
                    "Finance":     "dept-finance",
                    "Operations":  "dept-operations"
                }[emp.department] || "dept-default";

                const salary = new Intl.NumberFormat("en-IN", {
                    style: "currency", currency: "INR", maximumFractionDigits: 0
                }).format(emp.salary);

                const joinDate = new Date(emp.joinDate).toLocaleDateString("en-IN");

                const isAdmin = AuthService.isAdmin();
                const actionBtns = `
                    <button class="btn btn-sm btn-outline-info me-1 btn-view"
                        data-id="${emp.id}" title="View">
                        <i class="bi bi-eye"></i>
                    </button>
                    ${isAdmin ? `
                    <button class="btn btn-sm btn-outline-warning me-1 btn-edit"
                        data-id="${emp.id}" title="Edit">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger btn-delete"
                        data-id="${emp.id}"
                        data-name="${emp.firstName} ${emp.lastName}" title="Delete">
                        <i class="bi bi-trash"></i>
                    </button>` : ""}
                `;

                tbody.append(`
                    <tr class="${index % 2 === 0 ? "table-row-even" : "table-row-odd"}">
                        <td>${emp.id}</td>
                        <td><strong>${emp.firstName} ${emp.lastName}</strong></td>
                        <td>${emp.email}</td>
                        <td><span class="dept-badge ${deptClass}">${emp.department}</span></td>
                        <td>${emp.designation}</td>
                        <td>${salary}</td>
                        <td>${joinDate}</td>
                        <td>${statusBadge}</td>
                        <td>${actionBtns}</td>
                    </tr>
                `);
            });
        }

        // Update record count label
        const start = ((pagedResult.page - 1) * pagedResult.pageSize) + 1;
        const end   = Math.min(pagedResult.page * pagedResult.pageSize, pagedResult.totalCount);
        const label = pagedResult.totalCount === 0
            ? "No employees found"
            : `Showing ${start}–${end} of ${pagedResult.totalCount} employees`;
        $("#recordCountLabel").text(label);

        // Render pagination
        renderPagination(pagedResult);
    }

    /**
     * Renders a Bootstrap pagination bar.
     * @param {PagedResult} pagedResult
     */
    function renderPagination(pagedResult) {
        const container = $("#paginationContainer");
        container.empty();

        if (pagedResult.totalPages <= 1) return;

        const ul = $('<ul class="pagination pagination-sm mb-0"></ul>');

        // Prev button
        ul.append(`
            <li class="page-item ${!pagedResult.hasPrevPage ? "disabled" : ""}">
                <a class="page-link page-nav" data-page="${pagedResult.page - 1}" href="#">
                    <i class="bi bi-chevron-left"></i>
                </a>
            </li>
        `);

        // Page numbers — show window of 5 around current page
        const window = 2;
        let start = Math.max(1, pagedResult.page - window);
        let end   = Math.min(pagedResult.totalPages, pagedResult.page + window);

        if (start > 1) {
            ul.append(`<li class="page-item"><a class="page-link page-nav" data-page="1" href="#">1</a></li>`);
            if (start > 2) ul.append(`<li class="page-item disabled"><span class="page-link">…</span></li>`);
        }

        for (let p = start; p <= end; p++) {
            ul.append(`
                <li class="page-item ${p === pagedResult.page ? "active" : ""}">
                    <a class="page-link page-nav" data-page="${p}" href="#">${p}</a>
                </li>
            `);
        }

        if (end < pagedResult.totalPages) {
            if (end < pagedResult.totalPages - 1)
                ul.append(`<li class="page-item disabled"><span class="page-link">…</span></li>`);
            ul.append(`<li class="page-item"><a class="page-link page-nav" data-page="${pagedResult.totalPages}" href="#">${pagedResult.totalPages}</a></li>`);
        }

        // Next button
        ul.append(`
            <li class="page-item ${!pagedResult.hasNextPage ? "disabled" : ""}">
                <a class="page-link page-nav" data-page="${pagedResult.page + 1}" href="#">
                    <i class="bi bi-chevron-right"></i>
                </a>
            </li>
        `);

        container.append(ul);
    }

    // ── Dashboard ──────────────────────────────────────────────────────────────

    /**
     * Renders the 4 KPI summary cards on the dashboard.
     * @param {DashboardSummary} summary
     */
    function renderDashboardCards(summary) {
        $("#kpiTotal").text(summary.totalEmployees);
        $("#kpiActive").text(summary.activeEmployees);
        $("#kpiInactive").text(summary.inactiveEmployees);
        $("#kpiDepartments").text(summary.totalDepartments);
    }

    /**
     * Renders the department breakdown table/bar chart.
     * @param {DepartmentBreakdown[]} breakdown
     */
    function renderDepartmentBreakdown(breakdown) {
        const container = $("#deptBreakdown");
        container.empty();

        if (!breakdown || breakdown.length === 0) {
            container.html('<p class="text-muted">No data available.</p>');
            return;
        }

        breakdown.forEach(item => {
            const deptClass = {
                "Engineering": "dept-engineering",
                "Marketing":   "dept-marketing",
                "HR":          "dept-hr",
                "Finance":     "dept-finance",
                "Operations":  "dept-operations"
            }[item.department] || "dept-default";

            container.append(`
                <div class="dept-bar-row mb-2">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <span class="dept-badge ${deptClass} small">${item.department}</span>
                        <span class="text-muted small fw-semibold">${item.count} (${item.percentage}%)</span>
                    </div>
                    <div class="dept-bar-track">
                        <div class="dept-bar-fill ${deptClass}-bar"
                             style="width: ${item.percentage}%"></div>
                    </div>
                </div>
            `);
        });
    }

    /**
     * Renders the Recent Employees panel.
     * @param {Employee[]} employees
     */
    function renderRecentEmployees(employees) {
        const container = $("#recentEmployees");
        container.empty();

        if (!employees || employees.length === 0) {
            container.html('<p class="text-muted small">No employees yet.</p>');
            return;
        }

        employees.forEach(emp => {
            const statusBadge = emp.status === "Active"
                ? `<span class="badge bg-success">Active</span>`
                : `<span class="badge bg-secondary">Inactive</span>`;

            const deptClass = {
                "Engineering": "dept-engineering",
                "Marketing":   "dept-marketing",
                "HR":          "dept-hr",
                "Finance":     "dept-finance",
                "Operations":  "dept-operations"
            }[emp.department] || "dept-default";

            container.append(`
                <div class="recent-emp-item d-flex align-items-center gap-2 py-2 border-bottom">
                    <div class="emp-avatar">${emp.firstName.charAt(0)}${emp.lastName.charAt(0)}</div>
                    <div class="flex-grow-1">
                        <div class="fw-semibold small">${emp.firstName} ${emp.lastName}</div>
                        <div class="text-muted" style="font-size:0.75rem">${emp.designation}</div>
                    </div>
                    <div class="d-flex flex-column align-items-end gap-1">
                        <span class="dept-badge ${deptClass}" style="font-size:0.7rem">${emp.department}</span>
                        ${statusBadge}
                    </div>
                </div>
            `);
        });
    }

    // ── Modals ─────────────────────────────────────────────────────────────────

    /**
     * Pre-populates the Add/Edit form with employee data (for Edit mode).
     * @param {Employee} employee
     */
    function populateForm(employee) {
        $("#empId").val(employee.id);
        $("#firstName").val(employee.firstName);
        $("#lastName").val(employee.lastName);
        $("#email").val(employee.email);
        $("#phone").val(employee.phone);
        $("#department").val(employee.department);
        $("#designation").val(employee.designation);
        $("#salary").val(employee.salary);
        // Format date for input[type=date]
        const date = new Date(employee.joinDate);
        $("#joinDate").val(date.toISOString().split("T")[0]);
        $("#status").val(employee.status);
    }

    /**
     * Clears the Add/Edit form and resets validation state.
     */
    function clearForm() {
        $("#employeeForm")[0].reset();
        $("#empId").val("");
        $(".is-invalid").removeClass("is-invalid");
        $(".invalid-feedback").text("");
    }

    /**
     * Opens the View Employee modal and populates it with data.
     * @param {Employee} employee
     */
    function showViewModal(employee) {
        const salary = new Intl.NumberFormat("en-IN", {
            style: "currency", currency: "INR", maximumFractionDigits: 0
        }).format(employee.salary);

        const joinDate = new Date(employee.joinDate).toLocaleDateString("en-IN");

        const statusBadge = employee.status === "Active"
            ? `<span class="badge bg-success fs-6">Active</span>`
            : `<span class="badge bg-secondary fs-6">Inactive</span>`;

        const deptClass = {
            "Engineering": "dept-engineering",
            "Marketing":   "dept-marketing",
            "HR":          "dept-hr",
            "Finance":     "dept-finance",
            "Operations":  "dept-operations"
        }[employee.department] || "dept-default";

        $("#viewModalBody").html(`
            <div class="row g-3">
                <div class="col-12 text-center mb-2">
                    <div class="view-avatar mx-auto mb-2">
                        ${employee.firstName.charAt(0)}${employee.lastName.charAt(0)}
                    </div>
                    <h5 class="fw-bold mb-1">${employee.firstName} ${employee.lastName}</h5>
                    <p class="text-muted mb-0">${employee.designation}</p>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-muted small">Employee ID</label>
                    <p class="fw-semibold">#${employee.id}</p>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-muted small">Status</label>
                    <p>${statusBadge}</p>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-muted small">Email</label>
                    <p class="fw-semibold">${employee.email}</p>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-muted small">Phone</label>
                    <p class="fw-semibold">${employee.phone}</p>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-muted small">Department</label>
                    <p><span class="dept-badge ${deptClass}">${employee.department}</span></p>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-muted small">Salary</label>
                    <p class="fw-semibold text-success">${salary}</p>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-muted small">Join Date</label>
                    <p class="fw-semibold">${joinDate}</p>
                </div>
            </div>
        `);

        const modal = new bootstrap.Modal(document.getElementById("viewEmployeeModal"));
        modal.show();
    }

    // ── Toast ──────────────────────────────────────────────────────────────────

    /**
     * Shows a Bootstrap Toast notification.
     * @param {string} message - Toast message text
     * @param {string} type - 'success' | 'danger' | 'warning' | 'info'
     */
    function showToast(message, type = "success") {
        const iconMap = {
            success: "bi-check-circle-fill",
            danger:  "bi-x-circle-fill",
            warning: "bi-exclamation-triangle-fill",
            info:    "bi-info-circle-fill"
        };

        const toastEl = $("#appToast");
        toastEl.removeClass("text-bg-success text-bg-danger text-bg-warning text-bg-info");
        toastEl.addClass(`text-bg-${type}`);
        $("#toastIcon").attr("class", `bi ${iconMap[type] || iconMap.info} me-2`);
        $("#toastMessage").text(message);

        const toast = new bootstrap.Toast(toastEl[0], { delay: 3500 });
        toast.show();
    }

    // ── Inline Validation Errors ───────────────────────────────────────────────

    /**
     * Displays field-level inline error messages below form fields.
     * @param {Object} errors - { fieldName: errorMessage }
     */
    function showInlineErrors(errors) {
        Object.entries(errors).forEach(([field, message]) => {
            if (field === "_global") {
                showToast(message, "danger");
                return;
            }
            // Convert camelCase field name to selector (e.g. joinDate → #joinDate)
            const selector = `#${field}`;
            const input    = $(selector);
            if (input.length) {
                input.addClass("is-invalid");
                input.siblings(".invalid-feedback").text(message);
            }
        });
    }

    /**
     * Clears all inline error states on a form.
     * @param {string} formSelector - jQuery selector for the form
     */
    function clearInlineErrors(formSelector = "#employeeForm") {
        $(`${formSelector} .is-invalid`).removeClass("is-invalid");
        $(`${formSelector} .invalid-feedback`).text("");
    }

    // ── Role-Based UI ──────────────────────────────────────────────────────────

    /**
     * Shows/hides write action buttons based on current user role.
     * Called after every login via AuthService.isAdmin().
     */
    function applyRoleUI() {
        const isAdmin = AuthService.isAdmin();

        // Add Employee button in navbar
        if (isAdmin) {
            $("#btnAddEmployee").show();
            $("#viewerNotice").hide();
        } else {
            $("#btnAddEmployee").hide();
            $("#viewerNotice").show();
        }

        // Role badge in navbar
        const role      = AuthService.getRole() || "Viewer";
        const badgeClass = role === "Admin" ? "bg-danger" : "bg-secondary";
        $("#roleBadge")
            .text(role)
            .removeClass("bg-danger bg-secondary")
            .addClass(badgeClass);

        // Show current username
        const user = AuthService.getCurrentUser();
        if (user) $("#navUsername").text(user.username);
    }

    // ── View Switching ─────────────────────────────────────────────────────────

    /**
     * Shows the specified section and hides all others.
     * @param {string} section - 'login' | 'signup' | 'dashboard' | 'employees'
     */
    function showSection(section) {
        const sections = ["#loginSection", "#signupSection", "#dashboardSection", "#employeeSection"];
        sections.forEach(s => $(s).hide());
        $(`#${section}Section`).show();

        // Show/hide navbar based on auth state
        if (section === "login" || section === "signup") {
            $("#mainNav").hide();
        } else {
            $("#mainNav").show();
            // Highlight active nav link
            $(".nav-link").removeClass("active");
            if (section === "dashboard") $("#navDashboard").addClass("active");
            if (section === "employees") $("#navEmployees").addClass("active");
        }
    }

    return {
        renderEmployeeTable,
        renderPagination,
        renderDashboardCards,
        renderDepartmentBreakdown,
        renderRecentEmployees,
        populateForm,
        clearForm,
        showViewModal,
        showToast,
        showInlineErrors,
        clearInlineErrors,
        applyRoleUI,
        showSection
    };

})();

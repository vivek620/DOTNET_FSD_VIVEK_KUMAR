/**
 * employeeService.js
 * UPDATED in Mini Project 2.
 * All methods are now async delegates to storageService.
 * applyFilters() is removed — filtering/sorting now happen on the server.
 * Business logic only — never touches the DOM.
 */

const EmployeeService = (() => {

    /**
     * Returns a paginated, filtered, sorted list of employees from the API.
     * @param {Object} params - { search, department, status, sortBy, sortDir, page, pageSize }
     * @returns {Promise<PagedResult>}
     */
    async function getAll(params = {}) {
        return StorageService.getAll(params);
    }

    /**
     * Returns a single employee by ID.
     * @param {number} id
     * @returns {Promise<Employee>}
     */
    async function getById(id) {
        return StorageService.getById(id);
    }

    /**
     * Adds a new employee via the API.
     * @param {Object} data - Employee form data
     * @returns {Promise<Employee>}
     */
    async function add(data) {
        return StorageService.add(data);
    }

    /**
     * Updates an existing employee via the API.
     * @param {number} id
     * @param {Object} data - Updated employee data
     * @returns {Promise<Employee>}
     */
    async function update(id, data) {
        return StorageService.update(id, data);
    }

    /**
     * Removes an employee by ID via the API.
     * @param {number} id
     * @returns {Promise<void>}
     */
    async function remove(id) {
        return StorageService.remove(id);
    }

    return { getAll, getById, add, update, remove };

})();

/**
 * storageService.js
 * REPLACED in Mini Project 2.
 * All methods now make fetch() calls to the REST API.
 * Sends Authorization: Bearer <token> on every authenticated request.
 * The public method names (getAll, getById, add, update, remove) are identical
 * to Mini Project 1 — only the implementation inside changed.
 */

const StorageService = (() => {

    // ── Private: build request headers ────────────────────────────────────────

    /**
     * Builds standard headers for every API call.
     * @param {boolean} withAuth - Whether to attach the Bearer token.
     * @returns {Object} Headers object.
     */
    function _headers(withAuth = true) {
        const headers = { "Content-Type": "application/json" };
        if (withAuth) {
            const token = AuthService.getToken();
            if (token) headers["Authorization"] = `Bearer ${token}`;
        }
        return headers;
    }

    // ── Private: handle API response ──────────────────────────────────────────

    /**
     * Parses fetch response. Throws on non-OK HTTP status.
     * @param {Response} response
     * @returns {Promise<any>}
     */
    async function _handleResponse(response) {
        const text = await response.text();
        const data = text ? JSON.parse(text) : null;
        if (!response.ok) {
            const message = data?.message || `HTTP ${response.status}`;
            const error   = new Error(message);
            error.status  = response.status;
            error.data    = data;
            throw error;
        }
        return data;
    }

    // ── Public API ─────────────────────────────────────────────────────────────

    /**
     * Returns a paginated, filtered, sorted list of employees.
     * @param {Object} params - { search, department, status, sortBy, sortDir, page, pageSize }
     * @returns {Promise<PagedResult>}
     */
    async function getAll(params = {}) {
        const qs = new URLSearchParams();
        if (params.search)     qs.set("search",     params.search);
        if (params.department) qs.set("department", params.department);
        if (params.status)     qs.set("status",     params.status);
        if (params.sortBy)     qs.set("sortBy",     params.sortBy);
        if (params.sortDir)    qs.set("sortDir",    params.sortDir);
        qs.set("page",     params.page     || 1);
        qs.set("pageSize", params.pageSize || PAGE_SIZE);

        const response = await fetch(`${API_BASE_URL}/employees?${qs}`, {
            method:  "GET",
            headers: _headers()
        });
        return _handleResponse(response);
    }

    /**
     * Returns a single employee by ID.
     * @param {number} id
     * @returns {Promise<Employee>}
     */
    async function getById(id) {
        const response = await fetch(`${API_BASE_URL}/employees/${id}`, {
            method:  "GET",
            headers: _headers()
        });
        return _handleResponse(response);
    }

    /**
     * Creates a new employee.
     * @param {Object} employeeData
     * @returns {Promise<Employee>}
     */
    async function add(employeeData) {
        const response = await fetch(`${API_BASE_URL}/employees`, {
            method:  "POST",
            headers: _headers(),
            body:    JSON.stringify(employeeData)
        });
        return _handleResponse(response);
    }

    /**
     * Updates an existing employee.
     * @param {number} id
     * @param {Object} employeeData
     * @returns {Promise<Employee>}
     */
    async function update(id, employeeData) {
        const response = await fetch(`${API_BASE_URL}/employees/${id}`, {
            method:  "PUT",
            headers: _headers(),
            body:    JSON.stringify(employeeData)
        });
        return _handleResponse(response);
    }

    /**
     * Deletes an employee by ID.
     * @param {number} id
     * @returns {Promise<void>}
     */
    async function remove(id) {
        const response = await fetch(`${API_BASE_URL}/employees/${id}`, {
            method:  "DELETE",
            headers: _headers()
        });
        return _handleResponse(response);
    }

    /**
     * Returns dashboard summary data (KPIs + dept breakdown + recent employees).
     * @returns {Promise<DashboardSummary>}
     */
    async function getDashboard() {
        const response = await fetch(`${API_BASE_URL}/employees/dashboard`, {
            method:  "GET",
            headers: _headers()
        });
        return _handleResponse(response);
    }

    // ── Auth helpers (used by authService) ────────────────────────────────────

    /**
     * Calls POST /api/auth/login.
     * @param {Object} credentials - { username, password }
     * @returns {Promise<AuthResponse>}
     */
    async function login(credentials) {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method:  "POST",
            headers: _headers(false),
            body:    JSON.stringify(credentials)
        });
        return _handleResponse(response);
    }

    /**
     * Calls POST /api/auth/register.
     * @param {Object} data - { username, password, role }
     * @returns {Promise<AuthResponse>}
     */
    async function register(data) {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method:  "POST",
            headers: _headers(false),
            body:    JSON.stringify(data)
        });
        return _handleResponse(response);
    }

    return { getAll, getById, add, update, remove, getDashboard, login, register };

})();

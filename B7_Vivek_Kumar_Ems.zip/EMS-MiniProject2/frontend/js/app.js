/**
 * app.js
 * UPDATED in Mini Project 2.
 * All data operations are now async/await.
 * Pagination state (_state.page, _state.pageSize) tracked and sent with every request.
 * Debounced search (350ms).
 * Coordinates calls between service modules — contains no business logic.
 */

$(document).ready(function () {

    // ── Application State ──────────────────────────────────────────────────────
    const _state = {
        search:     "",
        department: "",
        status:     "",
        sortBy:     "name",
        sortDir:    "asc",
        page:       1,
        pageSize:   PAGE_SIZE,
        editingId:  null,
        deleteId:   null
    };

    let _searchDebounceTimer = null;

    // ── Initialisation ─────────────────────────────────────────────────────────

    function init() {
        // Always start at login
        UIService.showSection("login");
    }

    init();

    // ── Auth Guards ────────────────────────────────────────────────────────────

    function requireAuth() {
        if (!AuthService.isLoggedIn()) {
            UIService.showSection("login");
            return false;
        }
        return true;
    }

    // ── Load Dashboard ─────────────────────────────────────────────────────────

    async function loadDashboard() {
        if (!requireAuth()) return;
        try {
            const summary = await DashboardService.getSummary();
            UIService.renderDashboardCards(summary);
            UIService.renderDepartmentBreakdown(summary.departmentBreakdown);
            UIService.renderRecentEmployees(summary.recentEmployees);
        } catch (err) {
            UIService.showToast("Failed to load dashboard: " + err.message, "danger");
        }
    }

    // ── Load Employee List ─────────────────────────────────────────────────────

    async function loadEmployees() {
        if (!requireAuth()) return;
        try {
            const result = await EmployeeService.getAll({
                search:     _state.search,
                department: _state.department,
                status:     _state.status,
                sortBy:     _state.sortBy,
                sortDir:    _state.sortDir,
                page:       _state.page,
                pageSize:   _state.pageSize
            });
            UIService.renderEmployeeTable(result);
        } catch (err) {
            UIService.showToast("Failed to load employees: " + err.message, "danger");
        }
    }

    // ── Refresh after CRUD ─────────────────────────────────────────────────────

    async function refreshAll() {
        await loadDashboard();
        await loadEmployees();
    }

    // ════════════════════════════════════════════════════════════════════════════
    // NAVIGATION EVENTS
    // ════════════════════════════════════════════════════════════════════════════

    $("#navDashboard").on("click", function (e) {
        e.preventDefault();
        if (!requireAuth()) return;
        UIService.showSection("dashboard");
        loadDashboard();
    });

    $("#navEmployees").on("click", function (e) {
        e.preventDefault();
        if (!requireAuth()) return;
        UIService.showSection("employees");
        loadEmployees();
    });

    $("#navLogout").on("click", function (e) {
        e.preventDefault();
        AuthService.logout();
        UIService.showSection("login");
        UIService.showToast("You have been logged out.", "info");
    });

    // ════════════════════════════════════════════════════════════════════════════
    // AUTH EVENTS
    // ════════════════════════════════════════════════════════════════════════════

    // ── Login ──────────────────────────────────────────────────────────────────

    $("#loginForm").on("submit", async function (e) {
        e.preventDefault();
        UIService.clearInlineErrors("#loginForm");

        const data = {
            username: $("#loginUsername").val().trim(),
            password: $("#loginPassword").val()
        };

        const errors = ValidationService.validateAuthForm(data, false);
        if (Object.keys(errors).length > 0) {
            UIService.showInlineErrors(errors);
            return;
        }

        try {
            const result = await AuthService.login(data.username, data.password);
            if (result.success) {
                UIService.applyRoleUI();
                UIService.showSection("dashboard");
                loadDashboard();
                UIService.showToast(`Welcome back, ${AuthService.getCurrentUser().username}!`, "success");
            } else {
                UIService.showInlineErrors({ _global: result.message });
            }
        } catch (err) {
            UIService.showToast(err.message, "danger");
        }
    });

    // ── Show Signup / Login toggle ─────────────────────────────────────────────

    $("#linkToSignup").on("click", function (e) {
        e.preventDefault();
        UIService.showSection("signup");
    });

    $("#linkToLogin").on("click", function (e) {
        e.preventDefault();
        UIService.showSection("login");
    });

    // ── Signup ─────────────────────────────────────────────────────────────────

    $("#signupForm").on("submit", async function (e) {
        e.preventDefault();
        UIService.clearInlineErrors("#signupForm");

        const data = {
            username:        $("#signupUsername").val().trim(),
            password:        $("#signupPassword").val(),
            confirmPassword: $("#signupConfirmPassword").val(),
            role:            $("#signupRole").val()
        };

        const errors = ValidationService.validateAuthForm(data, true);
        if (Object.keys(errors).length > 0) {
            UIService.showInlineErrors(errors);
            return;
        }

        try {
            const result = await AuthService.signup(data.username, data.password, data.role);
            if (result.success) {
                UIService.showToast("Account created! Please log in.", "success");
                setTimeout(() => UIService.showSection("login"), 1500);
            } else {
                const mappedErrors = ValidationService.mapServerErrors({
                    status: 409,
                    data:   { message: result.message }
                });
                UIService.showInlineErrors(mappedErrors);
            }
        } catch (err) {
            const mappedErrors = ValidationService.mapServerErrors(err);
            UIService.showInlineErrors(mappedErrors);
        }
    });

    // ════════════════════════════════════════════════════════════════════════════
    // SEARCH / FILTER / SORT EVENTS
    // ════════════════════════════════════════════════════════════════════════════

    // ── Debounced Search ───────────────────────────────────────────────────────

    $("#searchInput").on("input", function () {
        clearTimeout(_searchDebounceTimer);
        _searchDebounceTimer = setTimeout(() => {
            _state.search = $(this).val().trim();
            _state.page   = 1;
            loadEmployees();
        }, 350);
    });

    // ── Department Filter ──────────────────────────────────────────────────────

    $("#deptFilter").on("change", function () {
        _state.department = $(this).val();
        _state.page       = 1;
        loadEmployees();
    });

    // ── Status Filter ──────────────────────────────────────────────────────────

    $("input[name='statusFilter']").on("change", function () {
        _state.status = $(this).val();
        _state.page   = 1;
        loadEmployees();
    });

    // ── Sort ───────────────────────────────────────────────────────────────────

    $("#sortSelect").on("change", function () {
        const [sortBy, sortDir] = $(this).val().split("-");
        _state.sortBy  = sortBy;
        _state.sortDir = sortDir;
        _state.page    = 1;
        loadEmployees();
    });

    // ── Pagination ─────────────────────────────────────────────────────────────

    $(document).on("click", ".page-nav", function (e) {
        e.preventDefault();
        const page = parseInt($(this).data("page"));
        if (!isNaN(page) && page >= 1) {
            _state.page = page;
            loadEmployees();
        }
    });

    // ════════════════════════════════════════════════════════════════════════════
    // EMPLOYEE CRUD EVENTS
    // ════════════════════════════════════════════════════════════════════════════

    // ── Open Add Employee Modal ────────────────────────────────────────────────

    $("#btnAddEmployee, #navAddEmployee").on("click", function () {
        _state.editingId = null;
        UIService.clearForm();
        $("#modalTitle").text("Add Employee");
        $("#btnSubmitEmployee").text("Add Employee");
        const modal = new bootstrap.Modal(document.getElementById("employeeModal"));
        modal.show();
    });

    // ── Submit Add / Edit Form ─────────────────────────────────────────────────

    $("#employeeForm").on("submit", async function (e) {
        e.preventDefault();
        UIService.clearInlineErrors("#employeeForm");

        const formData = {
            firstName:   $("#firstName").val().trim(),
            lastName:    $("#lastName").val().trim(),
            email:       $("#email").val().trim(),
            phone:       $("#phone").val().trim(),
            department:  $("#department").val(),
            designation: $("#designation").val().trim(),
            salary:      Number($("#salary").val()),
            joinDate:    new Date($("#joinDate").val()).toISOString(),
            status:      $("#status").val()
        };

        const errors = ValidationService.validateEmployeeForm(formData);
        if (Object.keys(errors).length > 0) {
            UIService.showInlineErrors(errors);
            return;
        }

        try {
            if (_state.editingId) {
                await EmployeeService.update(_state.editingId, formData);
                UIService.showToast("Employee updated successfully.", "success");
            } else {
                await EmployeeService.add(formData);
                UIService.showToast("Employee added successfully.", "success");
            }

            bootstrap.Modal.getInstance(document.getElementById("employeeModal")).hide();
            UIService.clearForm();
            _state.editingId = null;
            await refreshAll();

        } catch (err) {
            const mappedErrors = ValidationService.mapServerErrors(err);
            UIService.showInlineErrors(mappedErrors);
        }
    });

    // ── View Employee ──────────────────────────────────────────────────────────

    $(document).on("click", ".btn-view", async function () {
        const id = $(this).data("id");
        try {
            const employee = await EmployeeService.getById(id);
            UIService.showViewModal(employee);
        } catch (err) {
            UIService.showToast("Failed to load employee: " + err.message, "danger");
        }
    });

    // ── Edit Employee ──────────────────────────────────────────────────────────

    $(document).on("click", ".btn-edit", async function () {
        const id = $(this).data("id");
        try {
            const employee = await EmployeeService.getById(id);
            _state.editingId = id;
            UIService.clearForm();
            UIService.populateForm(employee);
            $("#modalTitle").text("Edit Employee");
            $("#btnSubmitEmployee").text("Update Employee");
            const modal = new bootstrap.Modal(document.getElementById("employeeModal"));
            modal.show();
        } catch (err) {
            UIService.showToast("Failed to load employee: " + err.message, "danger");
        }
    });

    // ── Delete: open confirmation ──────────────────────────────────────────────

    $(document).on("click", ".btn-delete", function () {
        _state.deleteId = $(this).data("id");
        const name      = $(this).data("name");
        $("#deleteEmployeeName").text(name);
        const modal = new bootstrap.Modal(document.getElementById("deleteModal"));
        modal.show();
    });

    // ── Delete: confirm ────────────────────────────────────────────────────────

    $("#btnConfirmDelete").on("click", async function () {
        if (!_state.deleteId) return;
        try {
            await EmployeeService.remove(_state.deleteId);
            UIService.showToast("Employee deleted successfully.", "success");
            bootstrap.Modal.getInstance(document.getElementById("deleteModal")).hide();
            _state.deleteId = null;

            // Navigate back to page 1 if needed
            _state.page = 1;
            await refreshAll();

        } catch (err) {
            UIService.showToast("Failed to delete employee: " + err.message, "danger");
        }
    });

    // ── Clear form when modal closes ───────────────────────────────────────────

    document.getElementById("employeeModal").addEventListener("hidden.bs.modal", function () {
        UIService.clearForm();
        UIService.clearInlineErrors("#employeeForm");
        _state.editingId = null;
    });

});

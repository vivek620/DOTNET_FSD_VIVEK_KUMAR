/**
 * validationService.js
 * MINOR UPDATE in Mini Project 2.
 * Added mapServerErrors() to translate API 409 Conflict responses
 * into field-level inline errors.
 * Never touches the DOM — returns error objects only.
 */

const ValidationService = (() => {

    // Valid department values
    const DEPARTMENTS = ["Engineering", "Marketing", "HR", "Finance", "Operations"];

    /**
     * Validates the employee add/edit form data.
     * @param {Object} data - Form field values
     * @param {boolean} isEdit - If true, ID field is not checked
     * @returns {Object} - Map of field name → error message (empty = valid)
     */
    function validateEmployeeForm(data) {
        const errors = {};

        if (!data.firstName || !data.firstName.trim())
            errors.firstName = "First name is required.";

        if (!data.lastName || !data.lastName.trim())
            errors.lastName = "Last name is required.";

        if (!data.email || !data.email.trim()) {
            errors.email = "Email is required.";
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
            errors.email = "Please enter a valid email address.";
        }

        if (!data.phone || !data.phone.trim()) {
            errors.phone = "Phone number is required.";
        } else if (!/^\d{10}$/.test(data.phone.trim())) {
            errors.phone = "Phone must be exactly 10 digits.";
        }

        if (!data.department || !data.department.trim()) {
            errors.department = "Department is required.";
        } else if (!DEPARTMENTS.includes(data.department.trim())) {
            errors.department = "Invalid department selected.";
        }

        if (!data.designation || !data.designation.trim())
            errors.designation = "Designation is required.";

        if (!data.salary && data.salary !== 0) {
            errors.salary = "Salary is required.";
        } else if (isNaN(Number(data.salary)) || Number(data.salary) <= 0) {
            errors.salary = "Salary must be a positive number.";
        }

        if (!data.joinDate || !data.joinDate.trim())
            errors.joinDate = "Join date is required.";

        if (!data.status || !data.status.trim()) {
            errors.status = "Status is required.";
        } else if (!["Active", "Inactive"].includes(data.status.trim())) {
            errors.status = "Status must be Active or Inactive.";
        }

        return errors;
    }

    /**
     * Validates the auth (signup/login) form data.
     * @param {Object} data - { username, password, confirmPassword? }
     * @param {boolean} isSignup - Include confirmPassword validation if true
     * @returns {Object} - Map of field name → error message
     */
    function validateAuthForm(data, isSignup = false) {
        const errors = {};

        if (!data.username || !data.username.trim())
            errors.username = "Username is required.";

        if (!data.password || !data.password.trim()) {
            errors.password = "Password is required.";
        } else if (data.password.length < 6) {
            errors.password = "Password must be at least 6 characters.";
        }

        if (isSignup) {
            if (!data.confirmPassword || !data.confirmPassword.trim()) {
                errors.confirmPassword = "Please confirm your password.";
            } else if (data.password !== data.confirmPassword) {
                errors.confirmPassword = "Passwords do not match.";
            }
        }

        return errors;
    }

    /**
     * Maps a 409 Conflict API error response to field-level inline errors.
     * ADDED in Mini Project 2.
     * @param {Error} err - Error thrown by storageService with err.status and err.data
     * @returns {Object} - Field-level errors or { _global: message }
     */
    function mapServerErrors(err) {
        if (err.status === 409) {
            const msg = err.data?.message || "";
            if (msg.toLowerCase().includes("email"))
                return { email: "An employee with this email already exists." };
            if (msg.toLowerCase().includes("username"))
                return { username: msg };
        }
        if (err.status === 400 && err.data?.errors) {
            // Map ASP.NET Core model state errors
            const errors = {};
            Object.entries(err.data.errors).forEach(([field, messages]) => {
                const key = field.charAt(0).toLowerCase() + field.slice(1);
                errors[key] = Array.isArray(messages) ? messages[0] : messages;
            });
            return errors;
        }
        return { _global: err.message || "An unexpected error occurred." };
    }

    return { validateEmployeeForm, validateAuthForm, mapServerErrors };

})();

/**
 * config.js
 * Application configuration constants.
 * NEW in Mini Project 2 — replaces data.js as the configuration source.
 */

const API_BASE_URL = "http://localhost:5000/api";
const PAGE_SIZE    = 10;

/**
 * authService.js
 * UPDATED in Mini Project 2.
 * login() and signup() call /api/auth/* endpoints.
 * Stores the returned JWT token and role in-memory (never in localStorage — XSS risk).
 * Exposes getToken() so storageService can send Authorization: Bearer on every request.
 */

const AuthService = (() => {

    // ── In-memory session state ────────────────────────────────────────────────
    let _session = null; // { username, role, token }

    // ── Public API ─────────────────────────────────────────────────────────────

    /**
     * Registers a new user via POST /api/auth/register.
     * @param {string} username
     * @param {string} password
     * @param {string} role - 'Admin' or 'Viewer'
     * @returns {Promise<{ success: boolean, message: string }>}
     */
    async function signup(username, password, role = "Viewer") {
        try {
            const result = await StorageService.register({ username, password, role });
            return { success: true, message: result.message };
        } catch (err) {
            return { success: false, message: err.message };
        }
    }

    /**
     * Authenticates a user via POST /api/auth/login.
     * Stores token and role in-memory on success.
     * @param {string} username
     * @param {string} password
     * @returns {Promise<{ success: boolean, message: string }>}
     */
    async function login(username, password) {
        try {
            const result = await StorageService.login({ username, password });
            _session = {
                username: result.username,
                role:     result.role,
                token:    result.token
            };
            return { success: true, message: result.message };
        } catch (err) {
            return { success: false, message: err.message };
        }
    }

    /**
     * Clears the in-memory session. User must re-login.
     */
    function logout() {
        _session = null;
    }

    /**
     * Returns true if the user has an active in-memory session.
     * @returns {boolean}
     */
    function isLoggedIn() {
        return _session !== null && !!_session.token;
    }

    /**
     * Returns the current session user object, or null.
     * @returns {{ username: string, role: string, token: string } | null}
     */
    function getCurrentUser() {
        return _session;
    }

    /**
     * Returns the JWT token for use in Authorization headers.
     * @returns {string | null}
     */
    function getToken() {
        return _session ? _session.token : null;
    }

    /**
     * Returns true if the current user has the Admin role.
     * @returns {boolean}
     */
    function isAdmin() {
        return _session?.role === "Admin";
    }

    /**
     * Returns the current user's role string.
     * @returns {string | null}
     */
    function getRole() {
        return _session ? _session.role : null;
    }

    return { signup, login, logout, isLoggedIn, getCurrentUser, getToken, isAdmin, getRole };

})();

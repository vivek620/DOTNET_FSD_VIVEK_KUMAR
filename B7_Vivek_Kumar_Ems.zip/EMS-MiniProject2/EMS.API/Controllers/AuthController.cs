using EMS.API.DTOs;
using EMS.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EMS.API.Controllers
{
    /// <summary>
    /// Authentication endpoints: POST /register and POST /login.
    /// Both endpoints are AllowAnonymous — no token required.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [AllowAnonymous]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _authService;

        public AuthController(AuthService authService)
        {
            _authService = authService;
        }

        // ─── POST /api/auth/register ───────────────────────────────────────────

        /// <summary>
        /// Registers a new Admin or Viewer account.
        /// Returns 409 Conflict if username already exists.
        /// </summary>
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] AuthRequestDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var result = await _authService.RegisterAsync(dto);

            if (!result.Success)
                return Conflict(new { message = result.Message });

            return Ok(result);
        }

        // ─── POST /api/auth/login ──────────────────────────────────────────────

        /// <summary>
        /// Authenticates a user. Returns JWT token on success.
        /// Returns 401 on failure — does NOT reveal which field is wrong.
        /// </summary>
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] AuthRequestDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var result = await _authService.LoginAsync(dto);

            if (!result.Success)
                return Unauthorized(new { message = result.Message });

            return Ok(result);
        }
    }
}

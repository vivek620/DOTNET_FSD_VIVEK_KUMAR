using EMS.API.DTOs;
using EMS.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EMS.API.Controllers
{
    /// <summary>
    /// REST endpoints: GET (paged list), GET by id, POST, PUT, DELETE, GET /dashboard.
    /// All responses use EmployeeResponseDto — entity models are never serialised directly.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class EmployeesController : ControllerBase
    {
        private readonly EmployeeService _employeeService;

        public EmployeesController(EmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        // ─── GET /api/employees/dashboard ─────────────────────────────────────

        /// <summary>
        /// Returns dashboard KPIs, department breakdown, and last 5 employees.
        /// Must be declared before the {id} route to avoid route conflicts.
        /// </summary>
        [HttpGet("dashboard")]
        [Authorize(Roles = "Admin,Viewer")]
        public async Task<IActionResult> GetDashboard()
        {
            var summary = await _employeeService.GetDashboardAsync();
            return Ok(summary);
        }

        // ─── GET /api/employees ────────────────────────────────────────────────

        /// <summary>
        /// Paginated employee list with server-side search, filter, sort.
        /// Accepts: search, department, status, sortBy, sortDir, page, pageSize.
        /// </summary>
        [HttpGet]
        [Authorize(Roles = "Admin,Viewer")]
        public async Task<IActionResult> GetAll([FromQuery] EmployeeQueryParams queryParams)
        {
            var result = await _employeeService.GetAllAsync(queryParams);
            return Ok(result);
        }

        // ─── GET /api/employees/{id} ───────────────────────────────────────────

        /// <summary>Returns a single employee by ID. Returns 404 if not found.</summary>
        [HttpGet("{id:int}")]
        [Authorize(Roles = "Admin,Viewer")]
        public async Task<IActionResult> GetById(int id)
        {
            var employee = await _employeeService.GetByIdAsync(id);
            if (employee is null)
                return NotFound(new { message = $"Employee with ID {id} not found." });

            return Ok(employee);
        }

        // ─── POST /api/employees ───────────────────────────────────────────────

        /// <summary>
        /// Creates a new employee. Validates all fields server-side.
        /// Returns 409 Conflict if email already exists.
        /// </summary>
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([FromBody] EmployeeRequestDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var result = await _employeeService.CreateAsync(dto);
            if (result is null)
                return Conflict(new { message = "An employee with this email already exists." });

            return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
        }

        // ─── PUT /api/employees/{id} ───────────────────────────────────────────

        /// <summary>
        /// Updates an existing employee.
        /// Returns 404 if not found, 409 if email conflicts.
        /// </summary>
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Update(int id, [FromBody] EmployeeRequestDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var (found, emailConflict, result) = await _employeeService.UpdateAsync(id, dto);

            if (!found)
                return NotFound(new { message = $"Employee with ID {id} not found." });

            if (emailConflict)
                return Conflict(new { message = "Another employee with this email already exists." });

            return Ok(result);
        }

        // ─── DELETE /api/employees/{id} ────────────────────────────────────────

        /// <summary>Deletes an employee. Returns 404 if not found.</summary>
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _employeeService.DeleteAsync(id);
            if (!deleted)
                return NotFound(new { message = $"Employee with ID {id} not found." });

            return Ok(new { message = "Employee deleted successfully." });
        }
    }
}

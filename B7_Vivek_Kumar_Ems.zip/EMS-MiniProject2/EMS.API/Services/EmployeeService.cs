using EMS.API.DTOs;
using EMS.API.Models;
using Microsoft.EntityFrameworkCore;

namespace EMS.API.Services
{
    /// <summary>
    /// All employee business logic. Builds SQL queries applying search, department,
    /// status filters and sort — then paginates using Skip/Take.
    /// No data is ever loaded into memory before filtering.
    /// </summary>
    public class EmployeeService
    {
        private readonly IEmployeeRepository _repo;

        public EmployeeService(IEmployeeRepository repo)
        {
            _repo = repo;
        }

        // ─── Get paged list ────────────────────────────────────────────────────

        /// <summary>
        /// Returns a paginated, filtered, sorted list of employees.
        /// All filtering and sorting executes as SQL — not in JavaScript.
        /// </summary>
        public async Task<PagedResult<EmployeeResponseDto>> GetAllAsync(EmployeeQueryParams q)
        {
            var query = _repo.GetQueryable();

            // Search: WHERE (FirstName + ' ' + LastName LIKE '%term%' OR Email LIKE '%term%')
            if (!string.IsNullOrWhiteSpace(q.Search))
            {
                var term = q.Search.ToLower();
                query = query.Where(e =>
                    (e.FirstName.ToLower() + " " + e.LastName.ToLower()).Contains(term) ||
                    e.Email.ToLower().Contains(term));
            }

            // Department filter
            if (!string.IsNullOrWhiteSpace(q.Department))
                query = query.Where(e => e.Department == q.Department);

            // Status filter
            if (!string.IsNullOrWhiteSpace(q.Status))
                query = query.Where(e => e.Status == q.Status);

            // Sort (ORDER BY in SQL)
            query = (q.SortBy?.ToLower(), q.SortDir?.ToLower()) switch
            {
                ("salary", "desc") => query.OrderByDescending(e => e.Salary),
                ("salary", _)      => query.OrderBy(e => e.Salary),
                ("joindate", "desc") => query.OrderByDescending(e => e.JoinDate),
                ("joindate", _)    => query.OrderBy(e => e.JoinDate),
                (_, "desc")        => query.OrderByDescending(e => e.LastName)
                                           .ThenByDescending(e => e.FirstName),
                _                  => query.OrderBy(e => e.LastName)
                                           .ThenBy(e => e.FirstName)
            };

            var totalCount = await query.CountAsync();

            // Clamp pageSize
            var pageSize = Math.Min(Math.Max(q.PageSize, 1), 100);
            var page     = Math.Max(q.Page, 1);

            // Skip/Take executes in SQL
            var employees = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(e => MapToDto(e))
                .ToListAsync();

            return new PagedResult<EmployeeResponseDto>
            {
                Data       = employees,
                TotalCount = totalCount,
                Page       = page,
                PageSize   = pageSize
            };
        }

        // ─── Get by ID ─────────────────────────────────────────────────────────

        /// <summary>Returns a single employee DTO by ID, or null if not found.</summary>
        public async Task<EmployeeResponseDto?> GetByIdAsync(int id)
        {
            var e = await _repo.GetByIdAsync(id);
            return e is null ? null : MapToDto(e);
        }

        // ─── Create ────────────────────────────────────────────────────────────

        /// <summary>Creates a new employee. Returns null if email already exists.</summary>
        public async Task<EmployeeResponseDto?> CreateAsync(EmployeeRequestDto dto)
        {
            if (await _repo.EmailExistsAsync(dto.Email))
                return null;

            var employee = MapFromDto(dto);
            employee.CreatedAt = DateTime.UtcNow;
            employee.UpdatedAt = DateTime.UtcNow;

            await _repo.AddAsync(employee);
            await _repo.SaveChangesAsync();

            return MapToDto(employee);
        }

        // ─── Update ────────────────────────────────────────────────────────────

        /// <summary>
        /// Updates an existing employee.
        /// Returns false if email conflicts with another record.
        /// </summary>
        public async Task<(bool found, bool emailConflict, EmployeeResponseDto? dto)>
            UpdateAsync(int id, EmployeeRequestDto dto)
        {
            var employee = await _repo.GetByIdAsync(id);
            if (employee is null) return (false, false, null);

            if (await _repo.EmailExistsAsync(dto.Email, excludeId: id))
                return (true, true, null);

            employee.FirstName   = dto.FirstName;
            employee.LastName    = dto.LastName;
            employee.Email       = dto.Email;
            employee.Phone       = dto.Phone;
            employee.Department  = dto.Department;
            employee.Designation = dto.Designation;
            employee.Salary      = dto.Salary;
            employee.JoinDate    = dto.JoinDate;
            employee.Status      = dto.Status;
            employee.UpdatedAt   = DateTime.UtcNow;

            await _repo.UpdateAsync(employee);
            await _repo.SaveChangesAsync();

            return (true, false, MapToDto(employee));
        }

        // ─── Delete ────────────────────────────────────────────────────────────

        /// <summary>Deletes an employee by ID. Returns false if not found.</summary>
        public async Task<bool> DeleteAsync(int id)
        {
            var employee = await _repo.GetByIdAsync(id);
            if (employee is null) return false;

            await _repo.RemoveAsync(employee);
            await _repo.SaveChangesAsync();
            return true;
        }

        // ─── Dashboard ─────────────────────────────────────────────────────────

        /// <summary>
        /// Returns all dashboard data in a single call — computed in SQL Server.
        /// </summary>
        public async Task<DashboardSummaryDto> GetDashboardAsync()
        {
            var all = _repo.GetQueryable();

            var total       = await all.CountAsync();
            var active      = await all.CountAsync(e => e.Status == "Active");
            var inactive    = await all.CountAsync(e => e.Status == "Inactive");
            var deptCount   = await all.Select(e => e.Department).Distinct().CountAsync();

            var breakdown = await all
                .GroupBy(e => e.Department)
                .Select(g => new DepartmentBreakdownDto
                {
                    Department = g.Key,
                    Count      = g.Count(),
                    Percentage = total > 0 ? Math.Round((double)g.Count() / total * 100, 1) : 0
                })
                .OrderBy(d => d.Department)
                .ToListAsync();

            var recent = await all
                .OrderByDescending(e => e.CreatedAt)
                .ThenByDescending(e => e.Id)
                .Take(5)
                .Select(e => MapToDto(e))
                .ToListAsync();

            return new DashboardSummaryDto
            {
                TotalEmployees      = total,
                ActiveEmployees     = active,
                InactiveEmployees   = inactive,
                TotalDepartments    = deptCount,
                DepartmentBreakdown = breakdown,
                RecentEmployees     = recent
            };
        }

        // ─── Mapping helpers ───────────────────────────────────────────────────

        private static EmployeeResponseDto MapToDto(Employee e) => new()
        {
            Id          = e.Id,
            FirstName   = e.FirstName,
            LastName    = e.LastName,
            Email       = e.Email,
            Phone       = e.Phone,
            Department  = e.Department,
            Designation = e.Designation,
            Salary      = e.Salary,
            JoinDate    = e.JoinDate,
            Status      = e.Status,
            CreatedAt   = e.CreatedAt,
            UpdatedAt   = e.UpdatedAt
        };

        private static Employee MapFromDto(EmployeeRequestDto dto) => new()
        {
            FirstName   = dto.FirstName,
            LastName    = dto.LastName,
            Email       = dto.Email,
            Phone       = dto.Phone,
            Department  = dto.Department,
            Designation = dto.Designation,
            Salary      = dto.Salary,
            JoinDate    = dto.JoinDate,
            Status      = dto.Status
        };
    }
}

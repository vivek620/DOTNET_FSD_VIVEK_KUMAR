using EMS.API.Data;
using EMS.API.Models;
using Microsoft.EntityFrameworkCore;

namespace EMS.API.Services
{
    /// <summary>
    /// EF Core implementation of IEmployeeRepository.
    /// All database access for Employee entities flows through this class.
    /// </summary>
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly AppDbContext _db;

        public EmployeeRepository(AppDbContext db)
        {
            _db = db;
        }

        /// <inheritdoc/>
        public IQueryable<Employee> GetQueryable() => _db.Employees.AsQueryable();

        /// <inheritdoc/>
        public async Task<Employee?> GetByIdAsync(int id) =>
            await _db.Employees.FindAsync(id);

        /// <inheritdoc/>
        public async Task AddAsync(Employee employee)
        {
            await _db.Employees.AddAsync(employee);
        }

        /// <inheritdoc/>
        public Task UpdateAsync(Employee employee)
        {
            _db.Employees.Update(employee);
            return Task.CompletedTask;
        }

        /// <inheritdoc/>
        public Task RemoveAsync(Employee employee)
        {
            _db.Employees.Remove(employee);
            return Task.CompletedTask;
        }

        /// <inheritdoc/>
        public async Task<bool> EmailExistsAsync(string email, int? excludeId = null)
        {
            var query = _db.Employees.Where(e =>
                e.Email.ToLower() == email.ToLower());

            if (excludeId.HasValue)
                query = query.Where(e => e.Id != excludeId.Value);

            return await query.AnyAsync();
        }

        /// <inheritdoc/>
        public async Task SaveChangesAsync() =>
            await _db.SaveChangesAsync();
    }
}

using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using EMS.API.Data;
using EMS.API.DTOs;
using EMS.API.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace EMS.API.Services
{
    /// <summary>
    /// Owns all authentication logic.
    /// Handles user registration (BCrypt hash), login (BCrypt verify), and JWT generation.
    /// </summary>
    public class AuthService
    {
        private readonly AppDbContext  _db;
        private readonly IConfiguration _config;

        public AuthService(AppDbContext db, IConfiguration config)
        {
            _db     = db;
            _config = config;
        }

        // ─── Register ──────────────────────────────────────────────────────────

        /// <summary>
        /// Registers a new user. Returns failure if username already exists
        /// or password is too short.
        /// </summary>
        public async Task<AuthResponseDto> RegisterAsync(AuthRequestDto dto)
        {
            if (dto.Password.Length < 6)
                return new AuthResponseDto
                {
                    Success = false,
                    Message = "Password must be at least 6 characters."
                };

            var exists = await _db.Users
                .AnyAsync(u => u.Username.ToLower() == dto.Username.ToLower());

            if (exists)
                return new AuthResponseDto
                {
                    Success = false,
                    Message = $"Username '{dto.Username}' is already taken."
                };

            var role = dto.Role is "Admin" or "Viewer" ? dto.Role : "Viewer";

            var user = new AppUser
            {
                Username     = dto.Username,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
                Role         = role,
                CreatedAt    = DateTime.UtcNow
            };

            _db.Users.Add(user);
            await _db.SaveChangesAsync();

            return new AuthResponseDto
            {
                Success  = true,
                Message  = "Registration successful.",
                Username = user.Username,
                Role     = user.Role
            };
        }

        // ─── Login ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Authenticates a user. Returns JWT token on success.
        /// Does NOT indicate which field is wrong on failure (security best practice).
        /// </summary>
        public async Task<AuthResponseDto> LoginAsync(AuthRequestDto dto)
        {
            var user = await _db.Users
                .FirstOrDefaultAsync(u => u.Username.ToLower() == dto.Username.ToLower());

            if (user is null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash))
                return new AuthResponseDto
                {
                    Success = false,
                    Message = "Invalid username or password."
                };

            var token = GenerateToken(user);

            return new AuthResponseDto
            {
                Success  = true,
                Message  = "Login successful.",
                Username = user.Username,
                Role     = user.Role,
                Token    = token
            };
        }

        // ─── Token Generation ──────────────────────────────────────────────────

        /// <summary>Generates a signed JWT containing userId, username, role, and expiry.</summary>
        public string GenerateToken(AppUser user)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name,           user.Username),
                new Claim(ClaimTypes.Role,           user.Role)
            };

            var key   = new SymmetricSecurityKey(
                            Encoding.UTF8.GetBytes(_config["Jwt:Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer:             _config["Jwt:Issuer"],
                audience:           _config["Jwt:Audience"],
                claims:             claims,
                expires:            DateTime.UtcNow.AddHours(
                                        double.Parse(_config["Jwt:ExpiryHours"] ?? "8")),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}

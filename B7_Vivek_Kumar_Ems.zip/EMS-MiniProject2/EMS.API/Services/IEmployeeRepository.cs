using EMS.API.DTOs;
using EMS.API.Models;

namespace EMS.API.Services
{
    /// <summary>
    /// Data access contract for Employee entities.
    /// Decouples EmployeeService from EF Core, enabling Moq unit tests.
    /// </summary>
    public interface IEmployeeRepository
    {
        /// <summary>Returns a queryable of all employees (not yet executed).</summary>
        IQueryable<Employee> GetQueryable();

        /// <summary>Returns an employee by ID, or null if not found.</summary>
        Task<Employee?> GetByIdAsync(int id);

        /// <summary>Adds a new employee to the store.</summary>
        Task AddAsync(Employee employee);

        /// <summary>Updates an existing employee in the store.</summary>
        Task UpdateAsync(Employee employee);

        /// <summary>Removes an employee from the store.</summary>
        Task RemoveAsync(Employee employee);

        /// <summary>Returns true if an email already exists, optionally excluding a specific employee ID.</summary>
        Task<bool> EmailExistsAsync(string email, int? excludeId = null);

        /// <summary>Saves all pending changes to the database.</summary>
        Task SaveChangesAsync();
    }
}

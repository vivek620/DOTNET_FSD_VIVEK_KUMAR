using EMS.API.Models;
using Microsoft.EntityFrameworkCore;

namespace EMS.API.Data
{
    /// <summary>
    /// EF Core DbContext. Defines DbSet for Employee and AppUser.
    /// Configures unique indexes and seeds 15 employees + 2 default users.
    /// </summary>
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Employee> Employees => Set<Employee>();
        public DbSet<AppUser> Users => Set<AppUser>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ── Unique index on Employee.Email ────────────────────────────────
            modelBuilder.Entity<Employee>()
                .HasIndex(e => e.Email)
                .IsUnique();

            // ── Unique index on AppUser.Username ──────────────────────────────
            modelBuilder.Entity<AppUser>()
                .HasIndex(u => u.Username)
                .IsUnique();

            // ── Seed: Default Users ───────────────────────────────────────────
            modelBuilder.Entity<AppUser>().HasData(
                new AppUser
                {
                    Id           = 1,
                    Username     = "admin",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin123"),
                    Role         = "Admin",
                    CreatedAt    = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc)
                },
                new AppUser
                {
                    Id           = 2,
                    Username     = "viewer",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("viewer123"),
                    Role         = "Viewer",
                    CreatedAt    = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc)
                }
            );

            // ── Seed: 15 Employees across all 5 departments ───────────────────
            modelBuilder.Entity<Employee>().HasData(
                new Employee
                {
                    Id          = 1,  FirstName = "Priya",   LastName = "Menon",
                    Email       = "priya.menon@xyz.com",      Phone = "9876543210",
                    Department  = "Engineering",  Designation = "Software Engineer",
                    Salary      = 750000,  JoinDate = new DateTime(2022, 6, 15, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 1, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 2,  FirstName = "Rahul",   LastName = "Sharma",
                    Email       = "rahul.sharma@xyz.com",     Phone = "9123456780",
                    Department  = "Engineering",  Designation = "Senior Developer",
                    Salary      = 1200000, JoinDate = new DateTime(2020, 3, 1, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 2, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 2, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 3,  FirstName = "Anita",   LastName = "Desai",
                    Email       = "anita.desai@xyz.com",      Phone = "9988776655",
                    Department  = "Engineering",  Designation = "QA Engineer",
                    Salary      = 650000,  JoinDate = new DateTime(2021, 9, 10, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Inactive",
                    CreatedAt   = new DateTime(2024, 1, 3, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 3, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 4,  FirstName = "Vikram",  LastName = "Nair",
                    Email       = "vikram.nair@xyz.com",      Phone = "9871234560",
                    Department  = "Marketing",  Designation = "Marketing Manager",
                    Salary      = 900000,  JoinDate = new DateTime(2019, 7, 20, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 4, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 4, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 5,  FirstName = "Sneha",   LastName = "Kulkarni",
                    Email       = "sneha.kulkarni@xyz.com",   Phone = "9765432100",
                    Department  = "Marketing",  Designation = "Content Strategist",
                    Salary      = 580000,  JoinDate = new DateTime(2023, 1, 5, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 5, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 5, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 6,  FirstName = "Arun",    LastName = "Patel",
                    Email       = "arun.patel@xyz.com",       Phone = "9654321009",
                    Department  = "HR",  Designation = "HR Manager",
                    Salary      = 820000,  JoinDate = new DateTime(2018, 4, 12, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 6, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 6, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 7,  FirstName = "Kavya",   LastName = "Reddy",
                    Email       = "kavya.reddy@xyz.com",      Phone = "9543210098",
                    Department  = "HR",  Designation = "HR Executive",
                    Salary      = 480000,  JoinDate = new DateTime(2022, 11, 30, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 7, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 7, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 8,  FirstName = "Deepak",  LastName = "Joshi",
                    Email       = "deepak.joshi@xyz.com",     Phone = "9432100987",
                    Department  = "HR",  Designation = "Recruiter",
                    Salary      = 450000,  JoinDate = new DateTime(2023, 5, 8, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Inactive",
                    CreatedAt   = new DateTime(2024, 1, 8, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 8, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 9,  FirstName = "Meera",   LastName = "Iyer",
                    Email       = "meera.iyer@xyz.com",       Phone = "9321009876",
                    Department  = "Finance",  Designation = "Finance Manager",
                    Salary      = 1050000, JoinDate = new DateTime(2017, 8, 25, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 9, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 9, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 10, FirstName = "Suresh",  LastName = "Kumar",
                    Email       = "suresh.kumar@xyz.com",     Phone = "9210098765",
                    Department  = "Finance",  Designation = "Accountant",
                    Salary      = 620000,  JoinDate = new DateTime(2021, 2, 14, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 10, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 10, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 11, FirstName = "Pooja",   LastName = "Singh",
                    Email       = "pooja.singh@xyz.com",      Phone = "9100987654",
                    Department  = "Finance",  Designation = "Financial Analyst",
                    Salary      = 780000,  JoinDate = new DateTime(2020, 10, 3, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Inactive",
                    CreatedAt   = new DateTime(2024, 1, 11, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 11, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 12, FirstName = "Rajesh",  LastName = "Verma",
                    Email       = "rajesh.verma@xyz.com",     Phone = "8987654321",
                    Department  = "Operations",  Designation = "Operations Manager",
                    Salary      = 950000,  JoinDate = new DateTime(2016, 6, 1, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 12, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 12, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 13, FirstName = "Nisha",   LastName = "Bhat",
                    Email       = "nisha.bhat@xyz.com",       Phone = "8876543210",
                    Department  = "Operations",  Designation = "Logistics Coordinator",
                    Salary      = 520000,  JoinDate = new DateTime(2022, 8, 18, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 13, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 13, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 14, FirstName = "Kiran",   LastName = "Rao",
                    Email       = "kiran.rao@xyz.com",        Phone = "8765432109",
                    Department  = "Operations",  Designation = "Supply Chain Analyst",
                    Salary      = 680000,  JoinDate = new DateTime(2021, 4, 22, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Active",
                    CreatedAt   = new DateTime(2024, 1, 14, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 14, 0, 0, 0, DateTimeKind.Utc)
                },
                new Employee
                {
                    Id          = 15, FirstName = "Amit",    LastName = "Ghosh",
                    Email       = "amit.ghosh@xyz.com",       Phone = "8654321098",
                    Department  = "Marketing",  Designation = "Digital Marketing Lead",
                    Salary      = 760000,  JoinDate = new DateTime(2019, 12, 10, 0, 0, 0, DateTimeKind.Utc),
                    Status      = "Inactive",
                    CreatedAt   = new DateTime(2024, 1, 15, 0, 0, 0, DateTimeKind.Utc),
                    UpdatedAt   = new DateTime(2024, 1, 15, 0, 0, 0, DateTimeKind.Utc)
                }
            );
        }
    }
}
